package laundryyuk.laundry_yuk.model;


public enum PaymentStatus {

    BELUM,
    SUDAH

}
