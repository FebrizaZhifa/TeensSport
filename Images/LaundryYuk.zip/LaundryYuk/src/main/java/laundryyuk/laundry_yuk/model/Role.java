package laundryyuk.laundry_yuk.model;


public enum Role {

    ADMIN,
    CUSTOMER

}
