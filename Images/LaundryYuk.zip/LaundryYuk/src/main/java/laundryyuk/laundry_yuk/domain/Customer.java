package laundryyuk.laundry_yuk.domain;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
public class Customer extends User {
}
