package laundryyuk.laundry_yuk.model;


public enum OrderStatus {

    MENUNGGU,
    DIPROSES,
    SELESAI

}
